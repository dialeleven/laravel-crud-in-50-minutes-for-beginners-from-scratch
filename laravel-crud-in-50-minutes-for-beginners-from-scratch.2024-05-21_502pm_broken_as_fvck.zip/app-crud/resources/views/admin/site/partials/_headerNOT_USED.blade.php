   <div class="flex items-center p-2 mb-3 bg-gray-100 rounded-lg shadow-md">
      <!--<img src="{{asset('assets/images/crud_create_read_update_delete-1024.webp')}}" alt="CRUD App" class="w-10 h-auto mr-2 rounded">-->
      <img src="{{asset('assets/images/android-chrome-512x512.png')}}" alt="CRUD App" class="w-10 h-auto mr-2 shadow">
      
      <span class="text-lg font-semibold text-gray-400">
         <span class="text-green-600">C</span><span class="text-green-600">R</span><span class="text-green-600">U</span><span class="text-green-600">D</span>
         <span class="">APP</span>
      </span>
   </div>
   