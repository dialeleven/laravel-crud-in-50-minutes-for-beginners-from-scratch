Hey, 
Can your Laravel app send emails yet? 😉 
Funny Coder