<!DOCTYPE html>
<html>
<head>
    <title>Laravel 11 Send Email with Attachment Example - Techsolutiontuff</title>
</head>
<body>
    <h1><?php echo e($mailData['title']); ?></h1>
  
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
    tempor incididunt ut labore et dolore magna aliqua.</p>
     
    <p>Thank you</p>
</body>
</html><?php /**PATH G:\My Documents 2\Websites\laravel-crud-in-50-minutes-for-beginners-from-scratch\app-crud\resources\views/emails/testMail.blade.php ENDPATH**/ ?>