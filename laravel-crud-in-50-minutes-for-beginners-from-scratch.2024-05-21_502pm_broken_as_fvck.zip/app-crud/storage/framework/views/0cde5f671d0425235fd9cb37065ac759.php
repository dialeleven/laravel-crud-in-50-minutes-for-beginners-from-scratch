Hey, 
Can your Laravel app send emails yet? 😉 
Funny Coder<?php /**PATH G:\My Documents 2\Websites\laravel-crud-in-50-minutes-for-beginners-from-scratch\app-crud\resources\views/emails/test-email.blade.php ENDPATH**/ ?>