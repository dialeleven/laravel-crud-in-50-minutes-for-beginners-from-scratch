<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <meta http-equiv="X-UA-Compatible" content="ie=edge">
   <title>Products index</title>
</head>
<body>

<h1>Products index</h1>

<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($product->id); ?> | 
<?php echo e($product->name); ?> | 
<?php echo e($product->qty); ?> | 
<?php echo e($product->price); ?> | 
<?php echo e($product->description); ?><br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>
</html><?php /**PATH G:\My Documents 2\Websites\laravel-crud-in-50-minutes-for-beginners-from-scratch\app-crud\resources\views/public/products/index.blade.php ENDPATH**/ ?>