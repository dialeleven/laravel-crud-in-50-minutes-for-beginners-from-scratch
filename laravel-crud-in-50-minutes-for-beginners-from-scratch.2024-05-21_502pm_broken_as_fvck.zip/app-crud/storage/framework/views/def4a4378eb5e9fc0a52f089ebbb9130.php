
<!DOCTYPE html>
<html>
<head>
    <title>Test Mail TITLE TAG</title>
</head>
<body>
    <h1>This is a test email</h1>
    <p>This email is sent from Laravel using XAMPP on Windows.</p>
</body>
</html><?php /**PATH G:\My Documents 2\Websites\laravel-crud-in-50-minutes-for-beginners-from-scratch\app-crud\resources\views/emails/test.blade.php ENDPATH**/ ?>