









<?php $__env->startSection('meta_title', 'Admin Users'); ?>
<?php $__env->startSection('meta_description', ''); ?>
<?php $__env->startSection('meta_keywords', 'CRUD app, products page, create, read, update, delete'); ?>

<?php $__env->startSection('h1', 'Admin Users'); ?>


<?php $__env->startSection('content'); ?>
   <!--
    <div class="jumbotron">
        <h1>Welcome to Your Application</h1>
        <p>This is the home page content.</p>
    </div>
   -->



   <!-- create/export csv buttons -->
   <div class="mt-3 mb-4">
      <a href="<?php echo e(route('adminusers.create')); ?>" class="inline-block bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded mr-2 text-xs uppercase font-bold">
         Add User
      </a>
   </div>
 
   <!-- pagination links - make sure controller is calling "Classname::paginate(X);"" -->
   

   
   <?php if(@session()->has('success')): ?>
   <div id="statusMessage" class="bg-green-300 py-1 px-4 rounded-md mt-2 mb-0">
      <?php echo e(session('success')); ?>

   </div>
   <?php endif; ?>
 
   <!-- data table -->
   <div class="mt-2 mb-3">
      <table class="w-full border-collapse rounded-md overflow-hidden text-sm">
         <thead>
            <tr class="bg-gray-200">
               <th class="py-2 px-3 font-bold border-b border-gray-400 text-left">ID</th>
               <th class="py-2 px-3 font-bold border-b border-gray-400 text-left">Username</th>
               <th class="py-2 px-3 font-bold border-b border-gray-400 text-left">Name</th>
               <th class="py-2 px-3 font-bold border-b border-gray-400 text-left">Email</th>
               <th class="py-2 px-3 font-bold border-b border-gray-400 text-left">Role</th>
               <th class="py-2 px-3 font-bold border-b border-gray-400 text-center">Acct Active</th>
               <th class="py-2 px-3 font-bold border-b border-gray-400">Edit</th>
               <th class="py-2 px-3 font-bold border-b border-gray-400">Delete</th>
            </tr>
         </thead>
         <tbody id="table-body">
         <?php $__currentLoopData = $adminusers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $adminuser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="<?php echo e($index % 2 === 0 ? 'bg-gray-100' : 'bg-white'); ?>">
               <td class="py-2 px-3 border-b border-gray-400"><?php echo e($adminuser->id); ?></td>
               <td class="py-2 px-3 border-b border-gray-400"><?php echo e($adminuser->username); ?></td>
               <td class="py-2 px-3 border-b border-gray-400"><?php echo e($adminuser->name); ?></td>
               <td class="py-2 px-3 border-b border-gray-400"><?php echo e($adminuser->email); ?></td>
               <td class="py-2 px-3 border-b border-gray-400"><?php echo e($adminuser->role_name); ?></td>
               <td class="py-2 px-3 border-b border-gray-400 text-center"><?php echo e($adminuser->account_active); ?></td>
               <td class="py-2 px-3 border-b border-gray-400 text-center">
                  <a href="<?php echo e(route('adminusers.edit', ['adminuser' => $adminuser])); ?>" class="inline-block bg-blue-500 hover:bg-blue-600 text-white py-1 px-3 rounded transition duration-300">Edit</a>
               </td>
               <td class="py-2 px-3 border-b border-gray-400 text-center">
                  <form method="POST" action="<?php echo e(route('adminusers.destroy', ['adminuser' => $adminuser])); ?>">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('delete'); ?>
                  <button type="submit" class="inline-block bg-red-600 hover:bg-red-700 text-white py-1 px-3 rounded transition duration-300" 
                     onclick="return confirm('Delete <?php echo e($adminuser->username); ?>?')">Delete</button>
                  <input type="hidden" name="page" value="<?php echo e(request()->query('page')); ?>">
                  </form>
               </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </tbody>
      </table>
   </div>
 
    
    
<?php $__env->stopSection(); ?>



<?php $__env->startPush('scripts_body'); ?>
<script type="text/javascript">
   // Function to remove the status message after a timeout
   function removeStatusMessage() {
     var statusMessage = document.getElementById('statusMessage');
     if (statusMessage) {
       statusMessage.style.opacity = '0';
       setTimeout(function() {
         statusMessage.remove();
       }, 500); // Adjust timeout duration (in milliseconds) as needed
     }
   }

   // Call the function after a certain period (e.g., 3 seconds)
   setTimeout(removeStatusMessage, 3000);
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.site.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\My Documents 2\Websites\laravel-crud-in-50-minutes-for-beginners-from-scratch\app-crud\resources\views/admin/adminusers/index.blade.php ENDPATH**/ ?>