









<?php $__env->startSection('meta_title', 'Edit User'); ?>


<?php $__env->startSection('h1', 'Edit User'); ?>



<?php $__env->startSection('content'); ?>
   
<form method="post" action="<?php echo e(route('adminusers.update', ['adminuser' => $adminuser])); ?>" enctype="multipart/form-data" class="max-w-xl text-sm border p-4 rounded-md shadow">
   <?php echo csrf_field(); ?>
   <?php echo method_field('put'); ?>
   
   
   <?php echo $__env->make('admin.site.partials.form_error_output', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   <div class="mb-4">
      <label class="block mb-1">Username</label>
      <input type="text" id="username" name="username" value="<?php echo e(old('username', $adminuser->username)); ?>" class="w-full border border-gray-300 rounded px-3 py-2">
   </div>
   <div class="mb-4">
      <label class="block mb-1">Password</label>
      <input type="password" id="password" name="password" value="<?php echo e(old('password')); ?>" class="w-full border border-gray-300 rounded px-3 py-2">
   </div>
   <div class="mb-4">
      <label class="block mb-1">Name</label>
      <input type="text" id="name" name="name" value="<?php echo e(old('name', $adminuser->name)); ?>" class="w-full border border-gray-300 rounded px-3 py-2">
   </div>
   <div class="mb-4">
      <label class="block mb-1">Email</label>
      <input type="email" id="email" name="email" required value="<?php echo e(old('email', $adminuser->email)); ?>" class="w-full border border-gray-300 rounded px-3 py-2">
   </div>
   <div class="mb-4">
      <label class="block mb-1">Role</label>
      <input type="radio" id="role_user" name="role_id" value="3" <?php if(old('role_id', $adminuser->role_id) == 3): ?> checked <?php endif; ?> class="border border-gray-300 rounded px-3 py-2 cursor-pointer">
      <label for="role_user" class="mr-4 cursor-pointer">User</label>

      <input type="radio" id="role_admin" name="role_id" value="2" <?php if(old('role_id', $adminuser->role_id) == 2): ?> checked <?php endif; ?> class="mr-1 border border-gray-300 rounded px-3 py-2 cursor-pointer">
      <label for="role_admin" class="mr-4 cursor-pointer">Admin</label>

      <input type="radio" id="role_superadmin" name="role_id" value="1" <?php if(old('role_id', $adminuser->role_id) == 1): ?> checked <?php endif; ?> class="mr-1 border border-gray-300 rounded px-3 py-2 cursor-pointer">
      <label for="role_superadmin" class="mr-4 cursor-pointer">Superadmin</label>
   </div>
   <div class="mb-4">
      <label class="block mb-1">Account Status</label>
      <div class="flex items-center">
         <input type="radio" id="account_active_active" name="account_active" value="1" <?php if(old('account_active', $adminuser->account_active) == 1): ?> checked <?php endif; ?> class="mr-1 cursor-pointer">
         <label for="account_active_active" class="mr-4 cursor-pointer">Active</label>
         
         <input type="radio" id="account_active_inactive" name="account_active" value="0" <?php if(old('account_active', $adminuser->account_active) === 0): ?> checked <?php endif; ?> class="mr-1 cursor-pointer">
         <label for="account_active_inactive" class="cursor-pointer">Inactive</label>
      </div>
   </div>
   <div class="mb-4">
      <input type="submit" value="Save" class="inline-block bg-blue-500 hover:bg-blue-600 text-white py-1 px-3 rounded transition duration-300 cursor-pointer">
      <input type="button" value="Cancel" class="inline-block bg-gray-500 hover:bg-gray-600 text-white py-1 px-3 rounded transition duration-300 cursor-pointer" onclick="location.href='<?php echo e(route('adminusers.index')); ?>';">
   </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.site.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\My Documents 2\Websites\laravel-crud-in-50-minutes-for-beginners-from-scratch\app-crud\resources\views/admin/adminusers/edit.blade.php ENDPATH**/ ?>