









<?php $__env->startSection('meta_title', 'Create Product'); ?>


<?php $__env->startSection('h1', 'Create Product'); ?>



<?php $__env->startSection('content'); ?>
   
<form method="post" action="<?php echo e(route('product.store')); ?>" enctype="multipart/form-data" class="max-w-xl text-sm border p-4 rounded-md shadow">
   <?php echo csrf_field(); ?>
   <?php echo method_field('post'); ?>
   
   
   <?php echo $__env->make('admin.site.partials.form_error_output', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   <div class="mb-4">
      <label class="block mb-1">Name</label>
      <input type="text" id="name" name="name" value="<?php echo e(old('name')); ?>" class="w-full border border-gray-300 rounded px-3 py-2">
   </div>
   <div class="mb-4">
      <label class="block mb-1">Quantity</label>
      <input type="text" id="qty" name="qty" value="<?php echo e(old('qty')); ?>" class="w-full border border-gray-300 rounded px-3 py-2">
   </div>
   <div class="mb-4">
      <label class="block mb-1">Price</label>
      <input type="text" id="price" name="price" value="<?php echo e(old('price')); ?>" class="w-full border border-gray-300 rounded px-3 py-2">
   </div>
   <div class="mb-4">
      <label class="block mb-1">Description</label>
      <input type="text" id="description" name="description" value="<?php echo e(old('description')); ?>" class="w-full border border-gray-300 rounded px-3 py-2">
   </div>
   <div class="mb-4">
      <label class="block mb-1">Image</label>
      <input type="file" name="image" class="w-full">
   </div>
   <div class="mb-4">
      <input type="submit" value="Save" class="inline-block bg-blue-500 hover:bg-blue-600 text-white py-1 px-3 rounded transition duration-300 cursor-pointer">
      <input type="button" value="Cancel" class="inline-block bg-gray-500 hover:bg-gray-600 text-white py-1 px-3 rounded transition duration-300 cursor-pointer" onclick="location.href='<?php echo e(route('product.index')); ?>';">
   </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.site.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\My Documents 2\Websites\laravel-crud-in-50-minutes-for-beginners-from-scratch\app-crud\resources\views/admin/products/create.blade.php ENDPATH**/ ?>