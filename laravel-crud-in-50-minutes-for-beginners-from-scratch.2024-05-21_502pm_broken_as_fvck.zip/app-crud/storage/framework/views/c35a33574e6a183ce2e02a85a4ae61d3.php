   
   <?php if($errors->any()): ?>
   <div class="mb-3">
      <ul class="error-list">
         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php
         $i = 0;

         // extract input name/id from error message
         preg_match('/^The (.*?) field/i', $error, $matches);
         $inputNameOrId = $matches[1] ?? '';
         
         // extract input name/id from error message for "the password field" as it can output
         // multiple errors (e.g. password too short, one upper/lowercase letter, etc)
         if (preg_match('/^The password field/i', $error, $matches))
         {
            // no password error yet, so consolidate all other possible password errors
            if (empty($password_error))
            {
               $error = 'The password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, one number, and one special character.';
               $password_error = true; // password error found flag
            }
            // password error exists, so skip output of <li> error below
            else {
               continue;
            }
         }
         ?>
         <li class="error-list-item flex items-center bg-red-100 rounded-md p-1 mb-2">
            <span class="text-red-500 font-bold mr-2">X</span>
            <a href="#<?php echo e($inputNameOrId); ?>" class="underline"><?php echo e($error); ?></a>
         </li>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
   </div>
   <?php endif; ?><?php /**PATH G:\My Documents 2\Websites\laravel-crud-in-50-minutes-for-beginners-from-scratch\app-crud\resources\views/admin/site/partials/form_error_output.blade.php ENDPATH**/ ?>