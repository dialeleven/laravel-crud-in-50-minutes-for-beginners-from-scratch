https://code.tutsplus.com/image-resizing-made-easy-with-php--net-10362t

https://github.com/tutsplus/image-resizing-made-easy-with-php