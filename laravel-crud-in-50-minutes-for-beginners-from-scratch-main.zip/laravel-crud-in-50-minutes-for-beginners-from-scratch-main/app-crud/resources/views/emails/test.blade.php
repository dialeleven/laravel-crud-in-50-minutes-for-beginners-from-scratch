
<!DOCTYPE html>
<html>
<head>
    <title>Test Mail</title>
</head>
<body>
    <h1>This is a test email</h1>
    <p>This email is sent from Laravel using XAMPP on Windows.</p>
</body>
</html>